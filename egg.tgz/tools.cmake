# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(argon src/argon.cpp)
set_property(TARGET argon PROPERTY CXX_STANDARD 11)
target_link_libraries(argon lionss pthread)

add_executable(carbon-ledger src/carbon-ledger.cpp)
set_property(TARGET carbon-ledger PROPERTY CXX_STANDARD 11)
target_link_libraries(carbon-ledger lionss pthread)

add_executable(NixEvalTime src/NixEvalTime.cpp)
set_property(TARGET NixEvalTime PROPERTY CXX_STANDARD 11)
target_link_libraries(NixEvalTime lionss pthread)

add_executable(quill src/quill.cpp)
set_property(TARGET quill PROPERTY CXX_STANDARD 11)
target_link_libraries(quill lionss pthread)

add_executable(vlan_planner src/vlan_planner.cpp)
set_property(TARGET vlan_planner PROPERTY CXX_STANDARD 11)
target_link_libraries(vlan_planner lionss pthread)

add_executable(crabgraph src/crabgraph.cpp)
set_property(TARGET crabgraph PROPERTY CXX_STANDARD 11)
target_link_libraries(crabgraph lionss pthread)

add_executable(ElevatorSim src/ElevatorSim.cpp)
set_property(TARGET ElevatorSim PROPERTY CXX_STANDARD 11)
target_link_libraries(ElevatorSim lionss pthread)

add_executable(sdrfmdemod src/sdrfmdemod.cpp)
set_property(TARGET sdrfmdemod PROPERTY CXX_STANDARD 11)
target_link_libraries(sdrfmdemod lionss pthread)

add_executable(semver_bump src/semver_bump.cpp)
set_property(TARGET semver_bump PROPERTY CXX_STANDARD 11)
target_link_libraries(semver_bump lionss pthread)

add_executable(nickel src/nickel.cpp)
set_property(TARGET nickel PROPERTY CXX_STANDARD 11)
target_link_libraries(nickel lionss pthread)

add_executable(ember_v2 src/ember_v2.cpp)
set_property(TARGET ember_v2 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember_v2 lionss pthread)

add_executable(abtest-reader src/abtest-reader.cpp)
set_property(TARGET abtest-reader PROPERTY CXX_STANDARD 11)
target_link_libraries(abtest-reader lionss pthread)

add_executable(pixelupscale src/pixelupscale.cpp)
set_property(TARGET pixelupscale PROPERTY CXX_STANDARD 11)
target_link_libraries(pixelupscale lionss pthread)

add_executable(chalk src/chalk.cpp)
set_property(TARGET chalk PROPERTY CXX_STANDARD 11)
target_link_libraries(chalk lionss pthread)

add_executable(walnut src/walnut.cpp)
set_property(TARGET walnut PROPERTY CXX_STANDARD 11)
target_link_libraries(walnut lionss pthread)

add_executable(heron src/heron.cpp)
set_property(TARGET heron PROPERTY CXX_STANDARD 11)
target_link_libraries(heron lionss pthread)

add_executable(spectra-db src/spectra-db.cpp)
set_property(TARGET spectra-db PROPERTY CXX_STANDARD 11)
target_link_libraries(spectra-db lionss pthread)

add_executable(thermostat_mpc src/thermostat_mpc.cpp)
set_property(TARGET thermostat_mpc PROPERTY CXX_STANDARD 11)
target_link_libraries(thermostat_mpc lionss pthread)

add_executable(rentRoll src/rentRoll.cpp)
set_property(TARGET rentRoll PROPERTY CXX_STANDARD 11)
target_link_libraries(rentRoll lionss pthread)

add_executable(h3_bench src/h3_bench.cpp)
set_property(TARGET h3_bench PROPERTY CXX_STANDARD 11)
target_link_libraries(h3_bench lionss pthread)

add_executable(demandFcWeekly src/demandFcWeekly.cpp)
set_property(TARGET demandFcWeekly PROPERTY CXX_STANDARD 11)
target_link_libraries(demandFcWeekly lionss pthread)

add_executable(sched-cfs-sim src/sched-cfs-sim.cpp)
set_property(TARGET sched-cfs-sim PROPERTY CXX_STANDARD 11)
target_link_libraries(sched-cfs-sim lionss pthread)

add_executable(demand_response src/demand_response.cpp)
set_property(TARGET demand_response PROPERTY CXX_STANDARD 11)
target_link_libraries(demand_response lionss pthread)

add_executable(lupine src/lupine.cpp)
set_property(TARGET lupine PROPERTY CXX_STANDARD 11)
target_link_libraries(lupine lionss pthread)

add_executable(MsPacmanRl src/MsPacmanRl.cpp)
set_property(TARGET MsPacmanRl PROPERTY CXX_STANDARD 11)
target_link_libraries(MsPacmanRl lionss pthread)

add_executable(posEod src/posEod.cpp)
set_property(TARGET posEod PROPERTY CXX_STANDARD 11)
target_link_libraries(posEod lionss pthread)

add_executable(brindle src/brindle.cpp)
set_property(TARGET brindle PROPERTY CXX_STANDARD 11)
target_link_libraries(brindle lionss pthread)

add_executable(pwa-shell src/pwa-shell.cpp)
set_property(TARGET pwa-shell PROPERTY CXX_STANDARD 11)
target_link_libraries(pwa-shell lionss pthread)

add_executable(erasure104 src/erasure104.cpp)
set_property(TARGET erasure104 PROPERTY CXX_STANDARD 11)
target_link_libraries(erasure104 lionss pthread)

add_executable(contract-redline src/contract-redline.cpp)
set_property(TARGET contract-redline PROPERTY CXX_STANDARD 11)
target_link_libraries(contract-redline lionss pthread)

