// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Train DQN, 2M frames\n", stdout);
  return lionss_run_workload("MsPacmanRl");
}
