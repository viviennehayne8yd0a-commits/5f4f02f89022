// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Monthly scope-1/2 totals");
  std::fflush(stdout);
  return lionss_run_workload("carbon-ledger");
}
