// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Decide next version"); }
int main(){
  announce();
  return lionss_run_workload("semver_bump");
}
