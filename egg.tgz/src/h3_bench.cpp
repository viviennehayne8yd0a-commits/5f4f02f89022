// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "10k requests over HTTP/3");
  std::fflush(stdout);
  return lionss_run_workload("h3_bench");
}
