// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "NowCast AQI");
  std::fflush(stdout);
  return lionss_run_workload("ember_v2");
}
