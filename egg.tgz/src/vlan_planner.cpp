// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Allocate VLAN ids and trunks");
  std::fflush(stdout);
  return lionss_run_workload("vlan_planner");
}
