// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Extractive summary, 5 sentences\n", stdout);
  return lionss_run_workload("nickel");
}
