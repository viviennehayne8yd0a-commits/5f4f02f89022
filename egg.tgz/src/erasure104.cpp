// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Encode 4 parity, lose 3, recover");
  std::fflush(stdout);
  return lionss_run_workload("erasure104");
}
