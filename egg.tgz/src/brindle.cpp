// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Evaluate flags for 10k users"); }
int main(){
  announce();
  return lionss_run_workload("brindle");
}
