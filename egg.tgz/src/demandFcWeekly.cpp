// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("13-week forecast, ETS"); }
int main(){
  announce();
  return lionss_run_workload("demandFcWeekly");
}
