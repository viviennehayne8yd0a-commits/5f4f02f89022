// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Sequential test, 2 arms"); }
int main(){
  announce();
  return lionss_run_workload("abtest-reader");
}
