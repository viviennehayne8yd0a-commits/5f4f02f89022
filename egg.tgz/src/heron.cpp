// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Pool trips within 7 min detour\n", stdout);
  return lionss_run_workload("heron");
}
