// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Redline clauses between drafts"); }
int main(){
  announce();
  return lionss_run_workload("contract-redline");
}
