// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulate 10 s of CFS\n", stdout);
  return lionss_run_workload("sched-cfs-sim");
}
