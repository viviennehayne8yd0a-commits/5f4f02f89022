// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Execute notebook headless\n", stdout);
  return lionss_run_workload("quill");
}
