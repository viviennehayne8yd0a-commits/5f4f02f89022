// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Dose calculation, 5 beams"); }
int main(){
  announce();
  return lionss_run_workload("lupine");
}
