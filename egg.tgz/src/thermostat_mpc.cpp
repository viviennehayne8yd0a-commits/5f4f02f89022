// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Model-predictive heating schedule"); }
int main(){
  announce();
  return lionss_run_workload("thermostat_mpc");
}
