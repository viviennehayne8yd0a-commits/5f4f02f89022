// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("PIC sheath, 20k steps\n", stdout);
  return lionss_run_workload("argon");
}
