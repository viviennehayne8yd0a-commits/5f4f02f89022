// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Strongly connected components"); }
int main(){
  announce();
  return lionss_run_workload("crabgraph");
}
